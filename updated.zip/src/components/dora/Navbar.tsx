import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import { navItems } from "@/data/site";

export function Navbar() {
  const [active, setActive] = useState("home");
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && setActive(e.target.id)),
      { rootMargin: "-45% 0px -50% 0px" },
    );
    navItems.forEach((n) => { const el = document.getElementById(n.id); if (el) io.observe(el); });
    const onTop = () => window.scrollY < 80 && setActive("home");
    window.addEventListener("scroll", onTop, { passive: true });
    onTop();
    return () => { io.disconnect(); window.removeEventListener("scroll", onTop); };
  }, []);

  const link = (id: string, label: string) => (
    <a
      key={id}
      href={`#${id}`}
      onClick={() => setOpen(false)}
      aria-current={active === id ? "true" : undefined}
      className={`rounded-full px-3 py-2 text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${active === id ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
    >
      {label}
    </a>
  );

  return (
    <header className="sticky top-0 z-50 border-b bg-background/85 backdrop-blur">
      <nav aria-label="Main" className="mx-auto flex max-w-content items-center justify-between px-4 py-3 lg:justify-center">
        <a href="#home" className="font-display text-lg font-bold lg:hidden">Dora DAO</a>
        <div className="hidden flex-wrap justify-center gap-1 lg:flex">{navItems.map((n) => link(n.id, n.label))}</div>
        <button
          className="inline-flex min-h-11 min-w-11 items-center justify-center rounded-md lg:hidden"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          onClick={() => setOpen((o) => !o)}
        >
          {open ? <X /> : <Menu />}
        </button>
      </nav>
      {open && <div className="flex flex-col gap-1 border-t px-4 py-3 lg:hidden">{navItems.map((n) => link(n.id, n.label))}</div>}
    </header>
  );
}
