# Dora homepage additions

## What I’ll build
- Refine the existing Dora mascot so one recognizable character cycles through inclusive appearances across skin tones, gender expression, hair, clothing, and accessories, while keeping the same illustration style and automatic rotation.
- Add a **Find your place in Dora** section with clear paths for learning, community, building, funding, partnering, and volunteering.
- Expand **Welcome to GWY Island** into a stronger destination-style section inspired by the reference, while preserving the existing interactive artifacts.
- Add an **Upcoming events** section with dates, event details, and clear action buttons.
- Add a **Work with us** section for careers, volunteering, mentorship, and partnerships.
- Add a **Who we work with** section showing practical collaboration models for universities, companies, and organizations/NGOs.
- Update the page navigation so every new section is reachable and highlighted while scrolling.

## Visual direction
- Match the attached reference’s warm illustrated editorial feel: parchment surfaces, forest green, amber highlights, handwritten headings, compact cards, and playful details.
- Keep layouts responsive and readable on phones, tablets, and desktop.
- Reuse the current page’s semantic colors and controls rather than introducing a separate visual system.

## Content and interaction
- Keep all editable text and card data in the typed `src/data/` content layer.
- Use realistic placeholder copy and non-submitting placeholder links where final URLs were not provided.
- Respect reduced-motion settings for mascot rotation and subtle entry/hover movement.

## Verification
- Check the updated homepage at desktop and mobile sizes.
- Verify mascot rotation, navigation, section buttons, layout, and current build/runtime signals.
