<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Landing content lives in typed files under src/data/; components in src/components/dora/ only render it — so content edits never touch components.
- Theme tokens (fonts, section spacing, content width, radius) live in the top @theme block of src/styles.css — one place to re-theme.
- Hero mascot variants use cropped portraits from the supplied artwork via CDN asset pointers, listed in src/data/avatar.ts — preserves the original pixel art while allowing independent rotation.
