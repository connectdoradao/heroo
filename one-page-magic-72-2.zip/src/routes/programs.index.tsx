import { MascotSay } from "@/components/dora/MascotNarrator";
import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell, Reveal } from "@/components/dora/PageShell";
import { Button } from "@/components/ui/button";
import { programDetails } from "@/data/programDetails";
import { programCategories } from "@/data/programs";

const title = "Programs — Dora DAO";
const description = "Explore every Dora DAO program: learning, community, building and funding initiatives with their full stories.";

export const Route = createFileRoute("/programs/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProgramsPage,
});

function ProgramsPage() {
  const [cat, setCat] = useState<(typeof programCategories)[number]>("All");
  const list = programDetails.filter((p) => cat === "All" || p.category === cat);
  return (
    <PageShell story={["Welcome to the program shelf! Each one is its own little storybook.","Use the filters to find a story that fits you.","Tap any program to read how it began and where it's going.","Psst… every program was started by members just like you."]}>
      <section className="px-4 py-section">
        <div className="mx-auto max-w-content">
          <p className="text-sm font-bold uppercase tracking-widest text-accent">Programs</p>
          <h1 className="mt-2 font-display text-5xl font-bold md:text-6xl">Every program has a story</h1>
          <p className="mt-3 max-w-2xl text-muted-foreground">Pick a program to see how it started, who runs it, what it achieved and what's coming next.</p>
          <div role="group" aria-label="Filter programs" className="mt-6 flex flex-wrap gap-2">
            {programCategories.map((c) => <Button key={c} size="sm" variant={cat === c ? "default" : "outline"} aria-pressed={cat === c} onClick={() => setCat(c)}>{c}</Button>)}
          </div>
          <ul className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {list.map((p, i) => (
              <li key={p.id}>
                <Reveal delay={(i % 3) * 80}>
                  <Link to="/programs/$slug" params={{ slug: p.id }} className="group block overflow-hidden rounded-token border bg-card transition hover:-translate-y-1 hover:shadow-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
                    <img src={p.images[0]} alt="" loading="lazy" className="aspect-[3/2] w-full object-cover transition duration-500 group-hover:scale-105" />
                    <div className="p-5">
                      <p className="text-xs uppercase tracking-wider text-muted-foreground">{p.category}</p>
                      <h2 className="mt-1 text-xl font-bold">{p.name}</h2>
                      <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{p.tagline}</p>
                      <span className="mt-4 inline-block text-sm font-semibold text-primary group-hover:underline">Read the story →</span>
                    </div>
                  </Link>
                </Reveal>
              </li>
            ))}
          </ul>
        </div>
      </section>
      <MascotSay mascot={5} flip>"Every program here started as someone's small idea. Which story will you join?"</MascotSay>
    </PageShell>
  );
}
