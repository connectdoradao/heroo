import { MascotSay } from "@/components/dora/MascotNarrator";
import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell, PageHero, Reveal } from "@/components/dora/PageShell";
import { CountUp, Section } from "@/components/dora/shared";
import { Button } from "@/components/ui/button";
import { storyIntro, storyChapters, storyValues } from "@/data/story";
import { partners } from "@/data/site";

const title = "Our story — Dora DAO";
const description = "How Dora DAO grew from five friends at a kitchen table into a 60K-member global community.";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <PageShell story={["Hi, I'm Dora! Pull up a chair, let me tell you how it all began.","It started with five friends and one kitchen table…","Then the circle grew, city by city, country by country.","Every member added a new chapter to our story.","And the best part? The next chapter is yours."]}>
      <PageHero kicker={storyIntro.kicker} title={storyIntro.title} lede={storyIntro.lede} image={storyIntro.cover} />

      <section className="px-4 py-section">
        <ol className="relative mx-auto max-w-content space-y-16 before:absolute before:left-4 before:top-0 before:h-full before:w-0.5 before:bg-border md:before:left-1/2">
          {storyChapters.map((c, i) => (
            <li key={c.title} className="relative grid gap-6 pl-12 md:grid-cols-2 md:gap-12 md:pl-0">
              <span aria-hidden className="absolute left-2 top-2 h-5 w-5 rounded-full border-4 border-background bg-accent md:left-1/2 md:-translate-x-1/2" />
              <Reveal className={i % 2 ? "md:order-2" : ""}>
                <img src={c.image} alt={c.imageAlt} loading="lazy" className="aspect-[4/3] w-full rounded-token border object-cover" />
              </Reveal>
              <Reveal delay={120} className="self-center">
                <p className="text-sm font-bold uppercase tracking-widest text-accent">{c.year}</p>
                <h2 className="mt-1 font-display text-4xl font-bold">{c.title}</h2>
                {c.body.map((p) => <p key={p} className="mt-3 text-muted-foreground">{p}</p>)}
                {c.stat && (
                  <p className="mt-4 inline-flex items-baseline gap-2 rounded-full bg-secondary px-4 py-2">
                    <span className="text-2xl font-extrabold"><CountUp value={c.stat.value} suffix={c.stat.suffix} /></span>
                    <span className="text-sm">{c.stat.label}</span>
                  </p>
                )}
              </Reveal>
            </li>
          ))}
        </ol>
      </section>

      <MascotSay mascot={3}>"That's how a tiny circle became a global family. Here's what still holds us together…"</MascotSay>
      <Section id="values" title="What we believe">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {storyValues.map((v, i) => (
            <Reveal key={v.title} delay={i * 80} className="rounded-token border bg-card p-6">
              <h3 className="font-semibold">{v.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{v.body}</p>
            </Reveal>
          ))}
        </div>
        <h3 className="mb-3 mt-12 text-sm font-semibold uppercase tracking-wider text-muted-foreground">Partners who joined the journey</h3>
        <ul className="grid grid-cols-4 gap-3 sm:grid-cols-8">
          {partners.map((p) => <li key={p.name} title={p.name} className="flex aspect-square items-center justify-center rounded-token border bg-muted text-2xl font-bold text-muted-foreground">{p.logo}</li>)}
        </ul>
        <div className="mt-12 rounded-token bg-primary p-8 text-center text-primary-foreground">
          <p className="font-display text-4xl font-bold">The next chapter has your name in it.</p>
          <div className="mt-5 flex flex-wrap justify-center gap-3">
            <Button asChild variant="secondary"><Link to="/programs">Explore programs</Link></Button>
            <Button asChild variant="outline" className="bg-transparent"><Link to="/contact">Get in touch</Link></Button>
          </div>
        </div>
      </Section>
    </PageShell>
  );
}
