import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Download } from "lucide-react";
import { PageShell, PageHero, Reveal } from "@/components/dora/PageShell";
import { MascotSay } from "@/components/dora/MascotNarrator";
import { Button } from "@/components/ui/button";
import { islandIntro, islandSpots, booklets, residencies, residencySteps, type Booklet } from "@/data/islandPage";

const title = "GWY Island — Dora DAO";
const description = "Explore GWY Island with Dora: an interactive map of island artifacts, lore booklets and virtual residencies.";

export const Route = createFileRoute("/island")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: IslandPage,
});

function downloadBooklet(b: Booklet) {
  const url = URL.createObjectURL(new Blob([b.text], { type: "text/plain" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = `gwy-island-${b.id}.txt`;
  a.click();
  URL.revokeObjectURL(url);
}

function IslandPage() {
  const [activeId, setActiveId] = useState(islandSpots[0]!.id);
  const [visited, setVisited] = useState<Set<string>>(new Set([islandSpots[0]!.id]));
  const active = islandSpots.find((s) => s.id === activeId)!;
  const go = (id: string) => { setActiveId(id); setVisited((v) => new Set(v).add(id)); };
  const idx = islandSpots.findIndex((s) => s.id === activeId);

  return (
    <PageShell story={["Ahoy! Welcome to my favourite place in the world.", "Tap a spot on the map and I'll tell you its tale.", "Collect all six artifacts to complete your tour!", "Take a lore booklet home with you.", "Want to stay longer? Try a residency.", "See you on Island Day!"]}>
      <PageHero kicker={islandIntro.kicker} title={islandIntro.title} lede={islandIntro.lede} image={islandIntro.image}>
        <Button className="mt-6" onClick={() => document.getElementById("tour")?.scrollIntoView({ behavior: "smooth" })}>Start the tour with Dora</Button>
      </PageHero>

      <MascotSay mascot={4}>"Hold my hand, we're going exploring! Every spot hides a little story."</MascotSay>

      <section id="tour" className="scroll-mt-24 px-4 py-section">
        <div className="mx-auto max-w-content">
          <h2 className="font-display text-4xl font-bold md:text-5xl">The island sanctuary</h2>
          <p className="mt-1 text-muted-foreground">Artifacts found: {visited.size} / {islandSpots.length}</p>
          <div className="mt-2 h-2 w-full max-w-sm overflow-hidden rounded-full bg-muted">
            <div className="h-full bg-primary transition-all duration-500" style={{ width: `${(visited.size / islandSpots.length) * 100}%` }} />
          </div>
          <div className="mt-8 grid gap-6 lg:grid-cols-[1.4fr_1fr]">
            <div className="relative aspect-[4/3] overflow-hidden rounded-token border-2 border-primary/30 bg-secondary/40">
              <div className="absolute inset-[8%] rounded-[45%_55%_50%_50%] bg-accent/20 shadow-inner" aria-hidden />
              <div className="absolute inset-[18%] rounded-[50%_40%_55%_45%] bg-primary/15" aria-hidden />
              {islandSpots.map((s) => (
                <button
                  key={s.id}
                  onClick={() => go(s.id)}
                  aria-label={`${s.name} at ${s.place}`}
                  aria-pressed={s.id === activeId}
                  style={{ left: `${s.x}%`, top: `${s.y}%` }}
                  className={`absolute -translate-x-1/2 -translate-y-1/2 rounded-full border-2 bg-card p-2 text-2xl shadow-md transition hover:scale-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring md:text-3xl ${s.id === activeId ? "scale-110 border-primary ring-4 ring-primary/20" : "border-transparent"} ${visited.has(s.id) ? "" : "opacity-70"}`}
                >
                  <span aria-hidden>{s.icon}</span>
                </button>
              ))}
            </div>
            <div key={active.id} className="rounded-token border bg-card p-6 shadow-sm motion-safe:animate-in motion-safe:fade-in motion-safe:slide-in-from-right-2">
              <p className="text-sm font-bold uppercase tracking-widest text-accent">{active.place}</p>
              <h3 className="mt-1 font-display text-4xl font-bold">{active.icon} {active.name}</h3>
              <div className="mt-4 space-y-3">{active.tale.map((t) => <p key={t}>{t}</p>)}</div>
              <p className="mt-5 rounded-token bg-secondary/50 p-3 font-display text-2xl">Dora's lesson: "{active.lesson}"</p>
              <div className="mt-5 flex justify-between gap-2">
                <Button variant="outline" disabled={idx === 0} onClick={() => go(islandSpots[idx - 1]!.id)}>Previous</Button>
                <Button disabled={idx === islandSpots.length - 1} onClick={() => go(islandSpots[idx + 1]!.id)}>Next stop</Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <MascotSay mascot={9} flip>"Stories are better when you can keep them. Grab a booklet!"</MascotSay>

      <section className="px-4 py-section">
        <div className="mx-auto max-w-content">
          <h2 className="font-display text-4xl font-bold md:text-5xl">Lore booklets</h2>
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {booklets.map((b, i) => (
              <Reveal key={b.id} delay={i * 100}>
                <article className="h-full overflow-hidden rounded-token border bg-card shadow-sm transition hover:-translate-y-1 hover:shadow-md">
                  <img src={b.cover} alt={`${b.title} booklet cover`} loading="lazy" className="aspect-[4/3] w-full object-cover" />
                  <div className="p-5">
                    <h3 className="font-display text-3xl font-bold">{b.title}</h3>
                    <p className="text-sm text-muted-foreground">{b.pages} pages · {b.blurb}</p>
                    <Button variant="outline" className="mt-4" onClick={() => downloadBooklet(b)}><Download className="h-4 w-4" /> Download</Button>
                  </div>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="px-4 py-section">
        <div className="mx-auto max-w-content">
          <h2 className="font-display text-4xl font-bold md:text-5xl">Virtual residencies & retreats</h2>
          <p className="mt-1 text-muted-foreground">Stay a while. Build, rest and grow with fellow islanders.</p>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {residencies.map((r, i) => (
              <Reveal key={r.id} delay={i * 100}>
                <div className="h-full rounded-token border-2 border-dashed border-primary/30 bg-card p-6">
                  <span className="text-4xl" aria-hidden>{r.icon}</span>
                  <h3 className="mt-2 font-display text-3xl font-bold">{r.name}</h3>
                  <p className="text-sm font-semibold text-accent">{r.length}</p>
                  <p className="mt-2 text-muted-foreground">{r.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
          <ol className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {residencySteps.map((s, i) => (
              <li key={s} className="flex items-center gap-3 rounded-token bg-secondary/40 p-4">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary font-bold text-primary-foreground">{i + 1}</span>
                <span className="font-medium">{s}</span>
              </li>
            ))}
          </ol>
          <div className="mt-8 text-center"><Button size="lg">Apply for a residency</Button></div>
        </div>
      </section>
    </PageShell>
  );
}
