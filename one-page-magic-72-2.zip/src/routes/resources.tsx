import { MascotSay } from "@/components/dora/MascotNarrator";
import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { PageShell, Reveal } from "@/components/dora/PageShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { featuredResource, resources, resourceTypes } from "@/data/resources";

const title = "Resource Center — Dora DAO";
const description = "Research, guides, toolkits, member stories and videos from the Dora DAO community.";

export const Route = createFileRoute("/resources")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ResourcesPage,
});

function ResourcesPage() {
  const [type, setType] = useState<(typeof resourceTypes)[number]>("All");
  const [q, setQ] = useState("");
  const list = useMemo(() => {
    const s = q.trim().toLowerCase();
    return resources.filter((r) => (type === "All" || r.type === type) && (!s || `${r.title} ${r.excerpt}`.toLowerCase().includes(s)));
  }, [type, q]);

  return (
    <PageShell story={["Welcome to my library! Everything we've learned, in one place.","Search or filter to find just what you need.","Guides, videos, toolkits: all free, all made with love.","Found something useful? Share it with a friend!"]}>
      <section className="px-4 py-section">
        <div className="mx-auto max-w-content">
          <div className="text-center">
            <MascotSay mascot={10}>"Every story needs a toolkit. Here's ours, all free to use."</MascotSay>
            <h1 className="mt-2 font-display text-5xl font-bold md:text-6xl">Resource Center</h1>
            <p className="mt-2 text-muted-foreground">Discover a wealth of knowledge and insights to help you succeed.</p>
          </div>

          <Reveal className="mx-auto mt-10 max-w-4xl overflow-hidden rounded-token border bg-card shadow-lg">
            <div className="aspect-video">
              <iframe className="h-full w-full" src={`https://www.youtube-nocookie.com/embed/${featuredResource.youtubeId}`} title={featuredResource.title} loading="lazy" allow="accelerometer; autoplay; encrypted-media; picture-in-picture" allowFullScreen />
            </div>
            <div className="p-5"><h2 className="text-xl font-bold">{featuredResource.title}</h2><p className="text-sm text-muted-foreground">{featuredResource.description}</p></div>
          </Reveal>

          <div className="mt-12 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div role="group" aria-label="Filter by type" className="flex flex-wrap gap-2">
              {resourceTypes.map((t) => <Button key={t} size="sm" variant={type === t ? "default" : "outline"} aria-pressed={type === t} onClick={() => setType(t)}>{t}</Button>)}
            </div>
            <label className="relative md:w-72">
              <span className="sr-only">Search resources</span>
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
              <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search resources" className="pl-9" />
            </label>
          </div>

          {list.length === 0 ? (
            <p className="mt-10 text-center text-muted-foreground">No resources match your search.</p>
          ) : (
            <ul className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {list.map((r, i) => (
                <li key={r.id}>
                  <Reveal delay={(i % 3) * 80} className="flex h-full flex-col overflow-hidden rounded-token border bg-card transition hover:-translate-y-1 hover:shadow-lg">
                    <img src={r.image} alt="" loading="lazy" className="aspect-[5/3] w-full object-cover" />
                    <div className="flex flex-1 flex-col p-5">
                      <span className="w-fit rounded-full bg-secondary px-3 py-1 text-xs font-semibold">{r.type}</span>
                      <h2 className="mt-3 text-lg font-bold leading-snug">{r.title}</h2>
                      <p className="mt-2 flex-1 text-sm text-muted-foreground">{r.excerpt}</p>
                      <div className="mt-4 flex items-center justify-between text-sm">
                        <a href={r.url} className="font-semibold text-primary hover:underline">{r.type === "Videos" ? "Watch" : "Read more"} →</a>
                        <span className="text-muted-foreground">{r.readMinutes} min {r.type === "Videos" ? "watch" : "read"}</span>
                      </div>
                    </div>
                  </Reveal>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
    </PageShell>
  );
}
