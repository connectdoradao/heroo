import { MascotSay } from "@/components/dora/MascotNarrator";
import { useEffect, useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { CalendarDays, Clock, Handshake, MapPin, Sparkles, Users } from "lucide-react";
import { PageShell, Reveal } from "@/components/dora/PageShell";
import { CountUp, Section } from "@/components/dora/shared";
import { Button } from "@/components/ui/button";
import { events, eventStats, pastHighlights, type DoraEvent } from "@/data/events";

const title = "Events — Dora DAO";
const description = "Conferences, hackathons, circles and partner events from the Dora DAO community around the world.";

export const Route = createFileRoute("/events")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: EventsPage,
});

const hosts = ["All", "Dora DAO", "Partner"] as const;
const formats = ["Any format", "Online", "In person", "Hybrid"] as const;

const fmtMonth = (d: string) => new Date(d + "T00:00:00").toLocaleDateString("en", { month: "long", year: "numeric" });
const parts = (d: string) => {
  const x = new Date(d + "T00:00:00");
  return { day: x.getDate(), mon: x.toLocaleDateString("en", { month: "short" }), wk: x.toLocaleDateString("en", { weekday: "short" }) };
};

function Countdown({ date }: { date: string }) {
  const [now, setNow] = useState<number | null>(null);
  useEffect(() => { setNow(Date.now()); const t = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(t); }, []);
  const diff = now === null ? 0 : Math.max(0, new Date(date + "T00:00:00").getTime() - now);
  const units = [["days", 86400000], ["hrs", 3600000], ["min", 60000], ["sec", 1000]] as const;
  let rest = diff;
  return (
    <div className="flex gap-2" aria-label="Time until event">
      {units.map(([l, ms]) => { const v = Math.floor(rest / ms); rest -= v * ms; return (
        <div key={l} className="min-w-16 rounded-token bg-background/90 px-3 py-2 text-center text-foreground shadow">
          <span className="block text-2xl font-extrabold tabular-nums">{now === null ? "--" : String(v).padStart(2, "0")}</span>
          <span className="text-xs uppercase text-muted-foreground">{l}</span>
        </div>
      ); })}
    </div>
  );
}

function SeatBar({ e }: { e: DoraEvent }) {
  const pct = Math.round((e.seatsTaken / e.seats) * 100);
  return (
    <div>
      <div className="flex justify-between text-xs text-muted-foreground"><span className="flex items-center gap-1"><Users className="h-3.5 w-3.5" />{e.seatsTaken}/{e.seats} going</span><span>{pct >= 90 ? "Almost full!" : `${pct}%`}</span></div>
      <div className="mt-1 h-2 overflow-hidden rounded-full bg-muted"><div className={`h-full rounded-full ${pct >= 90 ? "bg-accent" : "bg-primary"}`} style={{ width: `${pct}%` }} /></div>
    </div>
  );
}

function TicketCard({ e }: { e: DoraEvent }) {
  const p = parts(e.date);
  return (
    <article className="group grid overflow-hidden rounded-token border bg-card transition hover:-translate-y-1 hover:shadow-lg sm:grid-cols-[1fr_7rem]">
      <div className="flex flex-col">
        <div className="relative aspect-[16/9] overflow-hidden">
          <img src={e.image} alt="" loading="lazy" className="h-full w-full object-cover transition duration-500 group-hover:scale-105" />
          <span className={`absolute left-3 top-3 flex items-center gap-1 rounded-full px-3 py-1 text-xs font-bold shadow ${e.host === "Partner" ? "bg-secondary text-secondary-foreground" : "bg-primary text-primary-foreground"}`}>
            {e.host === "Partner" ? <><Handshake className="h-3.5 w-3.5" />with {e.partner}</> : <><Sparkles className="h-3.5 w-3.5" />Dora DAO</>}
          </span>
        </div>
        <div className="flex flex-1 flex-col gap-2 p-5">
          <p className="text-xs font-bold uppercase tracking-widest text-accent">{e.kind} · {e.format}</p>
          <h3 className="text-lg font-bold">{e.title}</h3>
          <p className="flex items-center gap-1 text-xs text-muted-foreground"><MapPin className="h-3.5 w-3.5" />{e.city}<Clock className="ml-2 h-3.5 w-3.5" />{e.time}</p>
          <p className="flex-1 text-sm text-muted-foreground">{e.description}</p>
          <SeatBar e={e} />
        </div>
      </div>
      {/* ticket stub */}
      <div className="flex items-center justify-between gap-3 border-t-2 border-dashed bg-muted/60 p-4 sm:flex-col sm:justify-center sm:border-l-2 sm:border-t-0">
        <div className="text-center"><span className="block text-xs font-bold uppercase text-muted-foreground">{p.wk}</span><span className="block font-display text-5xl font-bold leading-none">{p.day}</span><span className="block text-sm font-bold uppercase">{p.mon}</span></div>
        <Button size="sm" asChild><a href={e.url}>RSVP</a></Button>
      </div>
    </article>
  );
}

function EventsPage() {
  const [host, setHost] = useState<(typeof hosts)[number]>("All");
  const [format, setFormat] = useState<(typeof formats)[number]>("Any format");
  const featured = events.find((e) => e.featured) ?? events[0]!;

  const grouped = useMemo(() => {
    const list = events
      .filter((e) => host === "All" || e.host === host)
      .filter((e) => format === "Any format" || e.format === format)
      .sort((a, b) => a.date.localeCompare(b.date));
    const m = new Map<string, DoraEvent[]>();
    list.forEach((e) => { const k = fmtMonth(e.date); m.set(k, [...(m.get(k) ?? []), e]); });
    return [...m.entries()];
  }, [host, format]);

  const chip = (activeV: boolean) => `rounded-full border px-4 py-2 text-sm font-semibold transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${activeV ? "border-primary bg-primary text-primary-foreground" : "bg-card hover:border-primary"}`;

  return (
    <PageShell story={["Ooh, something big is coming! Watch the countdown.","Here's our calendar. Dora events and partner events, side by side.","Filter to find one near you, or join online!","These are memories from past events. I was at all of them!","Want to host one with us? Let's talk!"]}>
      {/* Featured hero with live countdown */}
      <section className="relative isolate overflow-hidden px-4 py-20">
        <img src={featured.image} alt="" className="absolute inset-0 -z-10 h-full w-full object-cover" />
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-primary via-primary/85 to-primary/30" />
        <div className="mx-auto max-w-content text-primary-foreground">
          <Reveal>
            <p className="text-sm font-bold uppercase tracking-widest text-secondary">Next big gathering</p>
            <h1 className="mt-2 max-w-2xl font-display text-5xl font-bold leading-tight md:text-7xl">{featured.title}</h1>
            <p className="mt-3 flex flex-wrap items-center gap-3 text-primary-foreground/85"><CalendarDays className="h-4 w-4" />{new Date(featured.date + "T00:00:00").toDateString()}<MapPin className="h-4 w-4" />{featured.city}</p>
            <p className="mt-4 max-w-xl text-lg text-primary-foreground/85">{featured.description}</p>
            <div className="mt-6"><Countdown date={featured.date} /></div>
            <Button size="lg" variant="secondary" className="mt-6" asChild><a href={featured.url}>Save my spot</a></Button>
          </Reveal>
        </div>
      </section>

      {/* Stats ribbon */}
      <div className="border-y bg-secondary/60 px-4 py-6">
        <dl className="mx-auto grid max-w-content grid-cols-2 gap-4 text-center md:grid-cols-4">
          {eventStats.map((s) => (
            <div key={s.label}><dt className="text-sm text-muted-foreground">{s.label}</dt><dd className="text-3xl font-extrabold"><CountUp value={s.value} suffix={s.suffix} /></dd></div>
          ))}
        </dl>
      </div>

      <MascotSay mascot={1}>"Every event is a new page in our story. Pick one, and come say hi!"</MascotSay>
      <Section id="calendar" title="What's coming up" subtitle="Dora-hosted events and gatherings run with our partners — pick yours.">
        <div className="mb-8 flex flex-wrap gap-2" role="group" aria-label="Filter events">
          {hosts.map((h) => <button key={h} className={chip(host === h)} aria-pressed={host === h} onClick={() => setHost(h)}>{h === "Partner" ? "Partner events" : h === "Dora DAO" ? "By Dora DAO" : "All events"}</button>)}
          <span className="mx-1 w-px bg-border" aria-hidden />
          {formats.map((f) => <button key={f} className={chip(format === f)} aria-pressed={format === f} onClick={() => setFormat(f)}>{f}</button>)}
        </div>
        {grouped.length === 0 && <p className="rounded-token border bg-card p-8 text-center text-muted-foreground">No events match — try another filter.</p>}
        <div className="space-y-12">
          {grouped.map(([month, list]) => (
            <div key={month} className="relative border-l-2 border-dashed border-primary/30 pl-6">
              <span className="absolute -left-[9px] top-2 h-4 w-4 rounded-full bg-accent ring-4 ring-background" aria-hidden />
              <h3 className="font-display text-3xl font-bold">{month}</h3>
              <div className="mt-4 grid gap-5 md:grid-cols-2">{list.map((e) => <Reveal key={e.id}><TicketCard e={e} /></Reveal>)}</div>
            </div>
          ))}
        </div>
      </Section>

      <Section id="past" title="Memories from past events" subtitle="A peek at where we've been.">
        <ul className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {pastHighlights.map((p, i) => (
            <li key={p.title} className={`group relative overflow-hidden rounded-token border-4 border-card bg-card shadow-md transition hover:rotate-0 hover:scale-105 ${i % 2 ? "rotate-2" : "-rotate-2"}`}>
              <img src={p.image} alt={p.title} loading="lazy" className="aspect-square w-full object-cover" />
              <div className="p-3"><p className="font-display text-xl font-bold">{p.title}</p><p className="text-xs text-muted-foreground">{p.stat}</p></div>
            </li>
          ))}
        </ul>
      </Section>

      <section className="px-4 pb-section">
        <div className="mx-auto flex max-w-content flex-col items-center gap-4 rounded-token bg-primary p-10 text-center text-primary-foreground">
          <Handshake className="h-10 w-10 text-secondary" />
          <h2 className="font-display text-4xl font-bold">Want to host an event with us?</h2>
          <p className="max-w-xl text-primary-foreground/85">Universities, companies and NGOs co-host workshops, hackathons and circles with Dora chapters worldwide.</p>
          <Button variant="secondary" size="lg" asChild><a href="/contact">Partner with Dora</a></Button>
        </div>
      </section>
    </PageShell>
  );
}
