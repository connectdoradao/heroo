import { MascotSay } from "@/components/dora/MascotNarrator";
import { useState } from "react";
import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { CheckCircle2, Circle } from "lucide-react";
import { PageShell, PageHero, Reveal } from "@/components/dora/PageShell";
import { CountUp, Section } from "@/components/dora/shared";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { getProgram, programDetails } from "@/data/programDetails";

export const Route = createFileRoute("/programs/$slug")({
  loader: ({ params }) => {
    const program = getProgram(params.slug);
    if (!program) throw notFound();
    return { program };
  },
  head: ({ loaderData }) => {
    if (!loaderData) return { meta: [{ title: "Program not found — Dora DAO" }, { name: "robots", content: "noindex" }] };
    const p = loaderData.program;
    const t = `${p.name} — Dora DAO program`;
    return {
      meta: [
        { title: t },
        { name: "description", content: p.tagline },
        { property: "og:title", content: t },
        { property: "og:description", content: p.tagline },
        { property: "og:type", content: "article" },
        { property: "og:image", content: p.cover },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:image", content: p.cover },
      ],
    };
  },
  notFoundComponent: ProgramNotFound,
  component: ProgramPage,
});

function ProgramNotFound() {
  return (
    <PageShell>
      <div className="px-4 py-24 text-center">
        <h1 className="font-display text-5xl font-bold">Program not found</h1>
        <Button asChild className="mt-6"><Link to="/programs">See all programs</Link></Button>
      </div>
    </PageShell>
  );
}

const subnav = [
  ["story", "Story"], ["progress", "Progress"], ["gallery", "Pictures"], ["bts", "Behind the scenes"],
  ["voices", "Testimonials"], ["team", "Team"], ["fun", "Fun & activities"], ["agenda", "Agenda"], ["faq", "FAQ"],
] as const;

function ProgramPage() {
  const { program: p } = Route.useLoaderData();
  const [photo, setPhoto] = useState(0);
  const others = programDetails.filter((o) => o.id !== p.id).slice(0, 3);

  return (
    <PageShell story={[`Let me walk you through ${p.name}!`,"First, the numbers we're proud of…","Here's how the story unfolded.","Peek behind the scenes with me!","Meet the people who made it happen.","Ready to write the next chapter? Apply above!"]}>
      <PageHero kicker={p.category} title={p.name} lede={p.tagline} image={p.cover}>
        <div className="mt-6 flex flex-wrap gap-3">
          <Button asChild><a href={p.applyUrl}>Apply now</a></Button>
          <Button asChild variant="outline"><Link to="/programs">All programs</Link></Button>
        </div>
      </PageHero>

      <nav aria-label="On this page" className="sticky top-[60px] z-40 border-y bg-background/90 backdrop-blur">
        <ul className="mx-auto flex max-w-content gap-1 overflow-x-auto px-4 py-2 text-sm">
          {subnav.map(([id, label]) => <li key={id} className="shrink-0"><a href={`#${id}`} className="rounded-full px-3 py-1.5 text-muted-foreground hover:bg-muted hover:text-foreground">{label}</a></li>)}
        </ul>
      </nav>

      <section aria-label="Achievements" className="px-4 pt-12">
        <div className="mx-auto grid max-w-content grid-cols-2 gap-4 md:grid-cols-4">
          {p.achievements.map((a, i) => (
            <Reveal key={a.label} delay={i * 80} className="rounded-token border bg-card p-5 text-center">
              <p className="text-4xl font-extrabold text-primary"><CountUp value={a.value} suffix={a.suffix} /></p>
              <p className="mt-1 text-sm text-muted-foreground">{a.label}</p>
            </Reveal>
          ))}
        </div>
      </section>

      <MascotSay mascot={7}>"Grab a snack, this is the story of {p.name}, chapter by chapter."</MascotSay>
      <Section id="story" title="The storyline">
        <ol className="grid gap-6 md:grid-cols-3">
          {p.story.map((s, i) => (
            <Reveal key={s.title} delay={i * 120} className="relative rounded-token border bg-card p-6">
              <span className="font-display text-5xl font-bold text-accent">0{i + 1}</span>
              <h3 className="mt-2 text-lg font-bold">{s.title}</h3>
              <p className="mt-2 text-muted-foreground">{s.body}</p>
            </Reveal>
          ))}
        </ol>
        <p className="mt-6 text-muted-foreground">{p.description}</p>
      </Section>

      <Section id="progress" title="Progress so far" className="bg-muted/50">
        <div className="grid gap-8 lg:grid-cols-2">
          <div className="space-y-6">
            {p.progress.map((g) => (
              <Reveal key={g.label}>
                <div className="flex justify-between text-sm font-semibold"><span>{g.label}</span><span>{g.value}%</span></div>
                <Progress value={g.value} className="mt-2 h-3" aria-label={g.label} />
                <p className="mt-1 text-xs text-muted-foreground">{g.note}</p>
              </Reveal>
            ))}
          </div>
          <ol className="space-y-3">
            {p.milestones.map((m) => (
              <li key={m.title} className="flex items-center gap-3 rounded-token border bg-card p-3">
                {m.done ? <CheckCircle2 className="text-primary" aria-label="Done" /> : <Circle className="text-muted-foreground" aria-label="Upcoming" />}
                <span className="w-20 text-xs text-muted-foreground">{m.date}</span>
                <span className={m.done ? "font-semibold" : ""}>{m.title}</span>
              </li>
            ))}
          </ol>
        </div>
      </Section>

      <Section id="gallery" title="Pictures">
        <img key={photo} src={p.images[photo]} alt={`${p.name} photo ${photo + 1}`} className="aspect-[16/8] w-full animate-in fade-in rounded-token object-cover duration-500" />
        <div className="mt-3 flex gap-2">
          {p.images.map((src, i) => (
            <button key={src} onClick={() => setPhoto(i)} aria-label={`Show photo ${i + 1}`} className={`overflow-hidden rounded-token border-2 ${i === photo ? "border-primary" : "border-transparent"}`}>
              <img src={src} alt="" loading="lazy" className="h-16 w-24 object-cover" />
            </button>
          ))}
        </div>
      </Section>

      <Section id="bts" title="Behind the scenes" className="bg-muted/50">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {p.behindTheScenes.map((b, i) => (
            <Reveal key={b.caption} delay={i * 80}>
              <figure className="overflow-hidden rounded-token border bg-card">
                <img src={b.image} alt={b.caption} loading="lazy" className="aspect-[4/3] w-full object-cover" />
                <figcaption className="p-3 text-sm">{b.caption}</figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </Section>

      <Section id="voices" title="What participants say">
        <div className="grid gap-4 md:grid-cols-3">
          {p.testimonials.map((t, i) => (
            <Reveal key={t.name + i} delay={i * 100} className="rounded-token border bg-card p-6">
              <blockquote className="font-display text-2xl leading-snug">“{t.quote}”</blockquote>
              <div className="mt-4 flex items-center gap-3">
                <img src={t.avatar} alt="" loading="lazy" className="h-10 w-10 rounded-full object-cover" />
                <div><p className="font-semibold">{t.name}</p><p className="text-xs text-muted-foreground">{t.role}</p></div>
              </div>
            </Reveal>
          ))}
        </div>
      </Section>

      <Section id="team" title="The team behind it" className="bg-muted/50">
        <ul className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {p.team.map((m, i) => (
            <li key={m.role}><Reveal delay={i * 80} className="text-center">
              <img src={m.avatar} alt={m.name} loading="lazy" className="mx-auto aspect-square w-32 rounded-full border-4 border-background object-cover shadow" />
              <p className="mt-3 font-semibold">{m.name}</p><p className="text-sm text-muted-foreground">{m.role}</p>
            </Reveal></li>
          ))}
        </ul>
      </Section>

      <Section id="fun" title="Fun & other activities">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {p.activities.map((a, i) => (
            <Reveal key={a.title} delay={i * 80} className="rounded-token border bg-card p-6 transition hover:-translate-y-1 hover:shadow-md">
              <span className="text-4xl" aria-hidden>{a.emoji}</span>
              <h3 className="mt-3 font-bold">{a.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{a.body}</p>
            </Reveal>
          ))}
        </div>
      </Section>

      <Section id="agenda" title="Agenda" className="bg-muted/50">
        <ol className="space-y-3">
          {p.agenda.map((a) => (
            <li key={a.time}><Reveal className="grid gap-2 rounded-token border bg-card p-4 sm:grid-cols-[8rem_1fr]">
              <span className="font-bold text-accent">{a.time}</span>
              <div><p className="font-semibold">{a.title}</p><p className="text-sm text-muted-foreground">{a.detail}</p></div>
            </Reveal></li>
          ))}
        </ol>
        <h3 className="mt-10 font-semibold">Who can apply</h3>
        <ul className="mt-2 list-disc space-y-1 pl-5 text-sm">{p.whoCanApply.map((w) => <li key={w}>{w}</li>)}</ul>
      </Section>

      <Section id="faq" title="Questions">
        <Accordion type="single" collapsible className="rounded-token border bg-card px-4">
          {p.faqs.map((f) => <AccordionItem key={f.q} value={f.q}><AccordionTrigger>{f.q}</AccordionTrigger><AccordionContent>{f.a}</AccordionContent></AccordionItem>)}
        </Accordion>
        <h3 className="mb-4 mt-12 font-display text-3xl font-bold">More programs</h3>
        <ul className="grid gap-4 md:grid-cols-3">
          {others.map((o) => (
            <li key={o.id}><Link to="/programs/$slug" params={{ slug: o.id }} className="block rounded-token border bg-card p-4 hover:shadow-md">
              <p className="text-xs uppercase text-muted-foreground">{o.category}</p><p className="font-bold">{o.name}</p>
            </Link></li>
          ))}
        </ul>
      </Section>
    </PageShell>
  );
}
