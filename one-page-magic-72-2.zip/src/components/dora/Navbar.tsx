import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { navItems, pageLinks } from "@/data/site";

const pill = "rounded-full px-3 py-2 text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring";
const idle = "text-muted-foreground hover:text-foreground";
const on = "bg-primary text-primary-foreground";

/** variant "home" = section anchors + page links; "page" = Home + page links only. */
export function Navbar({ variant = "home" }: { variant?: "home" | "page" }) {
  const [active, setActive] = useState("home");
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (variant !== "home") return;
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && setActive(e.target.id)),
      { rootMargin: "-45% 0px -50% 0px" },
    );
    navItems.forEach((n) => { const el = document.getElementById(n.id); if (el) io.observe(el); });
    const onTop = () => window.scrollY < 80 && setActive("home");
    window.addEventListener("scroll", onTop, { passive: true });
    onTop();
    return () => { io.disconnect(); window.removeEventListener("scroll", onTop); };
  }, [variant]);

  const anchors = [<Link key="home" to="/" onClick={() => setOpen(false)} className={`${pill} ${idle}`}>Home</Link>];

  const pages = pageLinks.map((p) => (
    <Link key={p.to} to={p.to} onClick={() => setOpen(false)} activeOptions={{ exact: p.to !== "/programs" }} className={`${pill} border border-primary/30 font-semibold ${idle}`} activeProps={{ className: `${pill} ${on}` }}>{p.label}</Link>
  ));

  return (
    <header className="sticky top-0 z-50 border-b bg-background/85 backdrop-blur">
      <nav aria-label="Main" className="mx-auto flex max-w-content items-center justify-between px-4 py-3 xl:justify-center">
        <Link to="/" className="font-display text-lg font-bold xl:hidden">Dora DAO</Link>
        <div className="hidden flex-wrap items-center justify-center gap-1 xl:flex">{anchors}<span className="mx-1 h-5 w-px bg-border" aria-hidden />{pages}</div>
        <button className="inline-flex min-h-11 min-w-11 items-center justify-center rounded-md xl:hidden" aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open} onClick={() => setOpen((o) => !o)}>
          {open ? <X /> : <Menu />}
        </button>
      </nav>
      {open && <div className="flex flex-col gap-1 border-t px-4 py-3 xl:hidden">{pages}{anchors}</div>}
    </header>
  );
}
