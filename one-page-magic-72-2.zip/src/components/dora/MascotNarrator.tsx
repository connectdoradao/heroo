import { useEffect, useState } from "react";
import { X } from "lucide-react";
import { avatarVariants } from "@/data/avatar";
import { usePrefersReducedMotion } from "./shared";

/** Floating Dora storyteller: narrates the page line by line as the visitor scrolls. */
export function MascotNarrator({ lines }: { lines: string[] }) {
  const [step, setStep] = useState(0);
  const [hidden, setHidden] = useState(false);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    const onScroll = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      const pct = max > 0 ? window.scrollY / max : 0;
      setStep(Math.min(lines.length - 1, Math.floor(pct * lines.length)));
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [lines.length]);

  if (hidden || lines.length === 0) return null;
  const m = avatarVariants[step % avatarVariants.length]!;

  return (
    <aside aria-live="polite" aria-label="Dora tells the story" className="fixed bottom-4 left-4 z-40 flex max-w-[20rem] items-end gap-2">
      <img key={m.id} src={m.src} alt={m.label} className={`h-24 w-24 shrink-0 object-contain drop-shadow-lg ${reduced ? "" : "animate-in fade-in zoom-in-90 duration-500"}`} />
      <div className="relative mb-10 rounded-token border bg-card p-3 pr-7 text-sm shadow-lg">
        <span className="absolute -left-2 bottom-3 h-4 w-4 rotate-45 border-b border-l bg-card" aria-hidden />
        <p className="font-display text-lg font-bold leading-tight text-primary">Dora says</p>
        <p key={step} className={reduced ? "" : "animate-in fade-in slide-in-from-bottom-1 duration-500"}>{lines[step]}</p>
        <button onClick={() => setHidden(true)} aria-label="Hide Dora" className="absolute right-1 top-1 rounded p-1 text-muted-foreground hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><X className="h-3.5 w-3.5" /></button>
      </div>
    </aside>
  );
}

/** Inline storybook-style aside: a mascot with a speech bubble between sections. */
export function MascotSay({ children, mascot = 0, flip = false }: { children: React.ReactNode; mascot?: number; flip?: boolean }) {
  const m = avatarVariants[mascot % avatarVariants.length]!;
  return (
    <div className={`mx-auto flex max-w-content items-center gap-4 px-4 py-6 ${flip ? "flex-row-reverse" : ""}`}>
      <img src={m.src} alt={m.label} loading="lazy" className="h-28 w-28 shrink-0 object-contain drop-shadow-md motion-safe:animate-bounce [animation-duration:3s]" />
      <blockquote className="relative flex-1 rounded-token border-2 border-dashed border-primary/30 bg-card p-5 font-display text-2xl leading-snug shadow-sm md:text-3xl">{children}</blockquote>
    </div>
  );
}
