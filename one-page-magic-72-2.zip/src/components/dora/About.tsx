import { about, partners } from "@/data/site";
import { Section } from "./shared";

export function About() {
  return (
    <Section id="about" title={about.title}>
      <div className="grid gap-6 rounded-token border bg-card p-6 md:grid-cols-3 md:p-8">
        <div><h3 className="font-semibold">Why “Dora”?</h3><p className="mt-2 text-muted-foreground">{about.whyName}</p></div>
        <div><h3 className="font-semibold">How it works</h3><p className="mt-2 text-muted-foreground">{about.howItWorks}</p></div>
        <div><h3 className="font-semibold">Our story</h3><p className="mt-2 text-muted-foreground">{about.story}</p></div>
        <div className="md:col-span-3">
          <h3 className="mb-3 text-sm font-semibold uppercase tracking-wider text-muted-foreground">Our partners</h3>
          <ul className="grid grid-cols-4 gap-3 sm:grid-cols-8">
            {partners.map((p) => (
              <li key={p.name} title={p.name} className="flex aspect-square items-center justify-center rounded-token border bg-muted text-2xl font-bold text-muted-foreground transition hover:-translate-y-1 hover:text-foreground hover:shadow-md">
                <span aria-label={p.name}>{p.logo}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Section>
  );
}
