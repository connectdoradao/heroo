import { useEffect, useRef, useState, type ReactNode } from "react";
import { Navbar } from "./Navbar";
import { Footer } from "./Footer";
import { MascotNarrator } from "./MascotNarrator";
import { usePrefersReducedMotion } from "./shared";

export function PageShell({ children, story }: { children: ReactNode; story?: string[] }) {
  return (
    <>
      <Navbar variant="page" />
      <main id="main">{children}</main>
      <Footer />
      {story && <MascotNarrator lines={story} />}
    </>
  );
}

/** Fades + lifts children into view when scrolled to. */
export function Reveal({ children, className = "", delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(false);
  const reduced = usePrefersReducedMotion();
  useEffect(() => {
    if (reduced) { setShown(true); return; }
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => { if (e?.isIntersecting) { setShown(true); io.disconnect(); } }, { rootMargin: "0px 0px -10% 0px" });
    io.observe(el);
    return () => io.disconnect();
  }, [reduced]);
  return (
    <div ref={ref} style={{ transitionDelay: `${delay}ms` }} className={`transition-all duration-700 ease-out ${shown ? "translate-y-0 opacity-100" : "translate-y-6 opacity-0"} ${className}`}>
      {children}
    </div>
  );
}

export function PageHero({ kicker, title, lede, image, children }: { kicker: string; title: string; lede: string; image: string; children?: ReactNode }) {
  return (
    <section className="relative overflow-hidden px-4 pb-12 pt-14">
      <div className="mx-auto grid max-w-content items-center gap-8 lg:grid-cols-2">
        <Reveal>
          <p className="text-sm font-bold uppercase tracking-widest text-accent">{kicker}</p>
          <h1 className="mt-2 font-display text-5xl font-bold leading-tight md:text-6xl">{title}</h1>
          <p className="mt-4 text-lg text-muted-foreground">{lede}</p>
          {children}
        </Reveal>
        <Reveal delay={150}>
          <img src={image} alt="" className="aspect-[16/10] w-full rounded-token border object-cover shadow-lg" />
        </Reveal>
      </div>
    </section>
  );
}
