import { ArrowUpRight, Building2, Check, GraduationCap, HandHeart, HeartHandshake, Sprout, Users } from "lucide-react";
import { collaborations, workPaths } from "@/data/community";
import { Section } from "./shared";
import { Button } from "@/components/ui/button";

const workIcons = { team: Users, volunteer: HandHeart, mentor: HeartHandshake };
const collaborationIcons = { universities: GraduationCap, companies: Building2, organizations: Sprout };

export function WorkWithUs() {
  return (
    <Section id="workwithus" title="Work with us" subtitle="Bring your experience, your energy or your organization into Dora.">
      <div className="grid gap-4 md:grid-cols-3">
        {workPaths.map((path) => (
          <article key={path.title} className="flex flex-col rounded-token border bg-primary p-6 text-primary-foreground">
            {(() => { const Icon = workIcons[path.icon]; return <Icon className="h-8 w-8" aria-hidden="true" />; })()}
            <h3 className="mt-4 font-display text-3xl font-bold">{path.title}</h3>
            <p className="mt-2 flex-1 text-sm leading-relaxed opacity-80">{path.description}</p>
            <Button variant="secondary" className="mt-5 w-fit">{path.action}<ArrowUpRight /></Button>
          </article>
        ))}
      </div>

      <div className="mt-14">
        <div className="mb-6 max-w-2xl">
          <p className="text-sm font-bold uppercase text-muted-foreground">Partnerships in practice</p>
          <h3 className="mt-1 font-display text-4xl font-bold">Who we work with</h3>
          <p className="mt-2 text-muted-foreground">Collaboration should create something useful. Here is what that can look like.</p>
        </div>
        <div className="grid gap-4 lg:grid-cols-3">
          {collaborations.map((group) => (
            <article key={group.title} className="rounded-token border bg-card p-6">
              <div className="flex items-center gap-3">{(() => { const Icon = collaborationIcons[group.icon]; return <Icon className="h-7 w-7 text-primary" aria-hidden="true" />; })()}<h4 className="text-xl font-bold">{group.title}</h4></div>
              <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{group.description}</p>
              <ul className="mt-5 space-y-2">
                {group.examples.map((example) => <li key={example} className="flex items-center gap-2 text-sm"><Check className="h-4 w-4 text-primary" />{example}</li>)}
              </ul>
              <Button variant="outline" className="mt-6">Start a conversation<ArrowUpRight /></Button>
            </article>
          ))}
        </div>
      </div>
    </Section>
  );
}