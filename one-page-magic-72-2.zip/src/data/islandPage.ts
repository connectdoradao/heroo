import { img } from "./site";

export const islandIntro = {
  kicker: "A place built by women and girls",
  title: "Welcome to GWY Island",
  lede: "A safe space, a louder voice and a bigger dream. Walk the island with Dora, uncover its artifacts and find your own corner of it.",
  image: img("gwy-island-hero", 1200, 750),
};

/** Artifacts placed on the interactive island map (x/y in % of the map). */
export type IslandSpot = { id: string; icon: string; name: string; place: string; x: number; y: number; tale: string[]; lesson: string };
export const islandSpots: IslandSpot[] = [
  { id: "mirror", icon: "🪞", name: "Mirror of Truth", place: "Crystal Cove", x: 22, y: 30, tale: ["At the edge of Crystal Cove stands a mirror that shows not your face, but your voice.", "The first girl who looked into it saw herself speaking on a stage of thousands."], lesson: "Your voice is already enough." },
  { id: "seed", icon: "🌱", name: "Seed of Courage", place: "Sunrise Garden", x: 48, y: 22, tale: ["Every new citizen plants one seed in Sunrise Garden.", "It only sprouts the day you try something that scares you."], lesson: "Courage grows when you water it." },
  { id: "flag", icon: "🚩", name: "The Island Flag", place: "Summit Hill", x: 70, y: 35, tale: ["Drafted by 40 members over one weekend hackathon.", "Each colour stands for a value: courage, curiosity and care."], lesson: "We fly together." },
  { id: "anthem", icon: "🎵", name: "The Anthem Shell", place: "Echo Beach", x: 78, y: 65, tale: ["Hold the shell to your ear and you hear the anthem in nine languages.", "Members remix it every year for Island Day."], lesson: "Many languages, one song." },
  { id: "constitution", icon: "📜", name: "The Constitution", place: "Council Tree", x: 45, y: 58, tale: ["Ratified by a vote of 4,000 members under the Council Tree.", "Anyone can propose an amendment — two already have."], lesson: "The island belongs to all of us." },
  { id: "passport", icon: "🛂", name: "Island Passport", place: "Harbour Gate", x: 20, y: 70, tale: ["Every member receives a passport at the Harbour Gate.", "Stamps are earned at events around the world."], lesson: "Every journey leaves a stamp." },
];

export type Booklet = { id: string; title: string; pages: number; blurb: string; cover: string; text: string };
export const booklets: Booklet[] = [
  { id: "origins", title: "The Origin Tale", pages: 12, blurb: "How the island was dreamed into being.", cover: img("booklet-origins", 400, 520), text: "THE ORIGIN TALE\n\nOnce upon a time, a group of women and girls dreamed of a place where every voice mattered..." },
  { id: "artifacts", title: "Book of Artifacts", pages: 18, blurb: "The story behind every artifact on the island.", cover: img("booklet-artifacts", 400, 520), text: "BOOK OF ARTIFACTS\n\nThe Mirror of Truth, the Seed of Courage, the Flag, the Anthem Shell, the Constitution and the Passport..." },
  { id: "rituals", title: "Island Rituals", pages: 8, blurb: "Friday demos, gratitude threads and Island Day.", cover: img("booklet-rituals", 400, 520), text: "ISLAND RITUALS\n\nKindness first, ship often, share everything..." },
];

export type Residency = { id: string; icon: string; name: string; length: string; desc: string };
export const residencies: Residency[] = [
  { id: "r1", icon: "🏕️", name: "Weekend Retreat", length: "2 days", desc: "Unplug, reflect and meet fellow islanders in a guided online retreat." },
  { id: "r2", icon: "🛠️", name: "Builder Residency", length: "4 weeks", desc: "Ship a project with mentors, daily check-ins and a demo night at the end." },
  { id: "r3", icon: "✍️", name: "Storyteller Residency", length: "2 weeks", desc: "Write, record or draw your story and add it to the island library." },
];

export const residencySteps = ["Apply with a short note", "Meet your island guide", "Build, rest and share", "Earn your passport stamp"];
