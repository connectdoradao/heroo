import { img } from "./site";

export type EventHost = "Dora DAO" | "Partner";
export type EventFormat = "Online" | "In person" | "Hybrid";
export type EventKind = "Hackathon" | "Workshop" | "Conference" | "Meetup" | "Circle" | "Demo night";

export type DoraEvent = {
  id: string;
  title: string;
  host: EventHost;
  partner?: string;
  kind: EventKind;
  format: EventFormat;
  date: string; // ISO yyyy-mm-dd
  time: string;
  city: string;
  description: string;
  image: string;
  seats: number;
  seatsTaken: number;
  url: string;
  featured?: boolean;
};

/** Placeholder events — replace with real ones. Dates in ISO so they sort and group by month. */
export const events: DoraEvent[] = [
  { id: "ev1", title: "DoraDAO World Conference", host: "Dora DAO", kind: "Conference", format: "Hybrid", date: "2026-10-18", time: "10:00 IST", city: "Bengaluru, India", description: "Our flagship gathering: stories, workshops and new collaborations from chapters across the world.", image: img("ev-world-conf", 1200, 700), seats: 1200, seatsTaken: 980, url: "#", featured: true },
  { id: "ev2", title: "Dora AI Building Day", host: "Dora DAO", kind: "Hackathon", format: "Online", date: "2026-10-12", time: "14:00 UTC", city: "Online · Global", description: "Turn an AI idea into a working first version in one day, with mentors beside you.", image: img("ev-ai-day", 760, 480), seats: 500, seatsTaken: 312, url: "#" },
  { id: "ev3", title: "Girls Who Yap Circle", host: "Dora DAO", kind: "Circle", format: "In person", date: "2026-10-25", time: "17:00 WAT", city: "Lagos, Nigeria", description: "An open circle for girls and women to speak, listen and build confidence together.", image: img("ev-gwy-lagos", 760, 480), seats: 60, seatsTaken: 51, url: "#" },
  { id: "ev4", title: "Cloud Skills Bootcamp", host: "Partner", partner: "Institute A", kind: "Workshop", format: "Online", date: "2026-10-29", time: "16:00 UTC", city: "Online · Global", description: "A partner-led crash course on deploying your first app to the cloud.", image: img("ev-cloud", 760, 480), seats: 300, seatsTaken: 140, url: "#" },
  { id: "ev5", title: "Fellowship Demo Night", host: "Dora DAO", kind: "Demo night", format: "Online", date: "2026-11-03", time: "18:00 UTC", city: "Online · Global", description: "See what the latest founder fellows built with the community.", image: img("ev-demo-night", 760, 480), seats: 800, seatsTaken: 420, url: "#" },
  { id: "ev6", title: "Women in Product Meetup", host: "Partner", partner: "Company B", kind: "Meetup", format: "In person", date: "2026-11-09", time: "19:00 GMT", city: "London, UK", description: "Product leaders share what they wish they'd known in their first PM role.", image: img("ev-wip-london", 760, 480), seats: 120, seatsTaken: 118, url: "#" },
  { id: "ev7", title: "Campus Build Sprint", host: "Partner", partner: "Institute C", kind: "Hackathon", format: "In person", date: "2026-11-21", time: "09:00 SGT", city: "Singapore", description: "48 hours, mixed teams, real community problems to solve.", image: img("ev-campus-sprint", 760, 480), seats: 200, seatsTaken: 90, url: "#" },
  { id: "ev8", title: "Web3 Without the Hype", host: "Dora DAO", kind: "Workshop", format: "Hybrid", date: "2026-12-02", time: "15:00 EST", city: "New York, USA", description: "A grounded, beginner-friendly look at what Web3 is actually useful for.", image: img("ev-web3", 760, 480), seats: 250, seatsTaken: 60, url: "#" },
  { id: "ev9", title: "Impact Grants Showcase", host: "Partner", partner: "NGO D", kind: "Conference", format: "Online", date: "2026-12-14", time: "12:00 UTC", city: "Online · Global", description: "Grantees present the community projects funded this year.", image: img("ev-grants", 760, 480), seats: 600, seatsTaken: 205, url: "#" },
];

export const pastHighlights = [
  { title: "World Tour · Nairobi", stat: "1,400 attendees", image: img("past-nairobi", 600, 600) },
  { title: "GWY Summit 2025", stat: "62 speakers", image: img("past-gwy-summit", 600, 600) },
  { title: "DoraBoot Hack Week", stat: "180 projects", image: img("past-hackweek", 600, 600) },
  { title: "AI Academy Launch", stat: "9K signups", image: img("past-ai-launch", 600, 600) },
];

export const eventStats = [
  { label: "Events hosted", value: 320, suffix: "+" },
  { label: "Partner events", value: 85, suffix: "+" },
  { label: "Cities", value: 85 },
  { label: "Attendees", value: 48, suffix: "K" },
];
