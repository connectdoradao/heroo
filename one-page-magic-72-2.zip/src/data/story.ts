import { img } from "./site";

export type StoryChapter = {
  year: string;
  title: string;
  body: string[];
  image: string;
  imageAlt: string;
  stat?: { value: number; suffix?: string; label: string };
};

export const storyIntro = {
  kicker: "Our story",
  title: "How a kitchen table became a global island",
  lede:
    "Dora didn't start with a plan. It started with a question a few friends kept asking each other: why does finding your people feel so hard? This is how we answered it — one meetup, one member, one gift at a time.",
  cover: img("dora-story-cover", 1600, 800),
};

export const storyChapters: StoryChapter[] = [
  {
    year: "Early 2025",
    title: "Chapter 1 — The kitchen table",
    body: [
      "Five friends, one borrowed flat and a pot of chai. We met every Sunday to share what we were learning — code, design, writing, anything.",
      "Within weeks, friends brought friends. The kitchen got crowded, so we moved to a library room and gave the circle a name: Dora, the Greek word for “gift”.",
    ],
    image: img("story-kitchen", 900, 650),
    imageAlt: "Friends gathered around a kitchen table with laptops",
    stat: { value: 5, label: "founding friends" },
  },
  {
    year: "Mid 2025",
    title: "Chapter 2 — Girls Who Yap",
    body: [
      "Our first program, Girls Who Yap, gave women and non-binary members a stage to speak about what they build. The first session had 40 people. The tenth had 4,000.",
      "That's when we realised Dora wasn't a club anymore — it was a movement that needed structure.",
    ],
    image: img("story-gwy", 900, 650),
    imageAlt: "Speaker on stage at a Girls Who Yap session",
    stat: { value: 4, suffix: "K", label: "attendees at session ten" },
  },
  {
    year: "Late 2025",
    title: "Chapter 3 — Becoming a DAO",
    body: [
      "We handed the keys to the community. Members began proposing programs, voting on budgets and running their own city chapters.",
      "Transparency became our superpower: every rupee, dollar and euro is tracked in the open.",
    ],
    image: img("story-dao", 900, 650),
    imageAlt: "Members voting on a community proposal",
    stat: { value: 30, label: "city chapters launched" },
  },
  {
    year: "2026",
    title: "Chapter 4 — The world tour",
    body: [
      "The DoraDAO World Tour took us to 45 countries. We hosted hackathons in Lagos, fireside chats in Lisbon and bootcamps in Bengaluru.",
      "Members shipped 45 products, launched startups and landed first jobs — many of them mentored by people they met at Dora.",
    ],
    image: img("story-tour", 900, 650),
    imageAlt: "A Dora DAO world tour meetup in a city square",
    stat: { value: 60, suffix: "K", label: "members worldwide" },
  },
  {
    year: "Today & tomorrow",
    title: "Chapter 5 — Where we're going",
    body: [
      "We're building GWY Island: a home for every program, resource and person in Dora. Next up are grants for NGOs, an AI academy and fellowships for first-time founders.",
      "The story is still being written — and the next chapter has your name in it.",
    ],
    image: img("story-future", 900, 650),
    imageAlt: "An illustrated island representing the future of Dora",
  },
];

export const storyValues = [
  { title: "Every person is a gift", body: "We look for what someone can give, not what they lack." },
  { title: "Owned by members", body: "Decisions, budgets and programs are shaped by the community." },
  { title: "Build in public", body: "We share wins, failures and numbers openly." },
  { title: "Kindness scales", body: "Our code of conduct is the foundation for everything we do." },
];
