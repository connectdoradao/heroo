import { img } from "./site";
import { programs, type Program } from "./programs";

export type ProgramDetail = Program & {
  tagline: string;
  cover: string;
  story: { title: string; body: string }[];
  progress: { label: string; value: number; note: string }[];
  milestones: { date: string; title: string; done: boolean }[];
  achievements: { value: number; suffix?: string; label: string }[];
  behindTheScenes: { image: string; caption: string }[];
  testimonials: { quote: string; name: string; role: string; avatar: string }[];
  team: { name: string; role: string; avatar: string }[];
  activities: { emoji: string; title: string; body: string }[];
  agenda: { time: string; title: string; detail: string }[];
  faqs: { q: string; a: string }[];
};

const firstNames = ["Amara", "Leo", "Priya", "Sofía", "Kenji", "Zainab", "Noah", "Mei", "Tariq", "Ava", "Ravi", "Lena"];

export const programDetails: ProgramDetail[] = programs.map((p, i) => {
  const seed = p.id;
  const person = (k: number) => firstNames[(i * 3 + k) % firstNames.length]!;
  return {
    ...p,
    tagline: `${p.name} — where curious people become confident builders.`,
    cover: img(`${seed}-cover`, 1600, 700),
    story: [
      { title: "How it started", body: `${p.name} began as a small experiment inside a single Dora chapter. A handful of members wanted a space to ${p.category === "Funding" ? "fund ideas that banks ignore" : p.category === "Learning" ? "learn together without gatekeeping" : p.category === "Building" ? "ship real projects with real teammates" : "meet people who get them"}.` },
      { title: "The turning point", body: "After the first edition sold out in two days, the community voted to make it a flagship program with its own budget, mentors and city hosts." },
      { title: "Where it is today", body: `Today ${p.name} runs across multiple cities and online, with alumni coming back as mentors, organisers and sponsors.` },
    ],
    progress: [
      { label: "Seats filled this edition", value: 60 + (i * 7) % 35, note: "Applications close soon" },
      { label: "Curriculum delivered", value: 30 + (i * 11) % 60, note: "Weekly modules" },
      { label: "Funding goal reached", value: 45 + (i * 13) % 50, note: "Community + partners" },
    ],
    milestones: [
      { date: "Jan 2026", title: "Applications open", done: true },
      { date: "Feb 2026", title: "Cohort announced", done: true },
      { date: "Mar 2026", title: "Kick-off week", done: i % 2 === 0 },
      { date: "May 2026", title: "Demo day", done: false },
      { date: "Jun 2026", title: "Alumni celebration", done: false },
    ],
    achievements: [
      { value: 300 + i * 85, suffix: "+", label: "Participants" },
      { value: 6 + i, label: "Cities" },
      { value: 20 + i * 4, label: "Projects shipped" },
      { value: 92, suffix: "%", label: "Would recommend" },
    ],
    behindTheScenes: [0, 1, 2, 3].map((k) => ({
      image: img(`${seed}-bts-${k}`, 700, 500),
      caption: ["Planning the agenda on a whiteboard", "Volunteers setting up the venue", "Mentor briefing before kick-off", "Late-night pizza and debugging"][k]!,
    })),
    testimonials: [0, 1, 2].map((k) => ({
      quote: [
        "I walked in nervous and walked out with a team, a project and friends for life.",
        "The mentors treated my half-baked idea like it mattered. That changed everything.",
        "It's the most welcoming room I've ever been in — online or offline.",
      ][k]!,
      name: person(k),
      role: ["Participant, last edition", "Alumni mentor", "City host"][k]!,
      avatar: img(`${seed}-t-${k}`, 120, 120),
    })),
    team: [0, 1, 2, 3].map((k) => ({
      name: person(k + 4),
      role: ["Program lead", "Community manager", "Mentor coordinator", "Design & media"][k]!,
      avatar: img(`${seed}-team-${k}`, 240, 240),
    })),
    activities: [
      { emoji: "🎤", title: "Open-mic nights", body: "Share a win, a fail or a song." },
      { emoji: "🧩", title: "Puzzle hunts", body: "City-wide treasure hunts between teams." },
      { emoji: "🍲", title: "Potluck socials", body: "Bring a dish from home, meet the cohort." },
      { emoji: "🎨", title: "Sticker & zine jam", body: "Design merch for the next edition." },
    ],
    agenda: [
      { time: "Week 1", title: "Welcome & team formation", detail: "Meet your cohort, mentors and city host." },
      { time: "Week 2–3", title: "Deep-dive workshops", detail: "Hands-on sessions led by practitioners." },
      { time: "Week 4", title: "Mid-point check-in", detail: "Share progress, get feedback, adjust." },
      { time: "Week 5", title: "Build sprint", detail: "Focused time with mentors on call." },
      { time: "Final week", title: "Demo day & celebration", detail: "Present to the community and partners." },
    ],
    faqs: [
      { q: "Is it free?", a: "Yes. Dora programs are free for members, funded by the DAO and partners." },
      { q: "Can I join online?", a: "Most editions run hybrid — join from anywhere with an internet connection." },
      { q: "How much time does it take?", a: "Plan for 4–6 hours a week during the program." },
    ],
  };
});

export const getProgram = (slug: string) => programDetails.find((p) => p.id === slug);
