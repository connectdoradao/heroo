import { img } from "./site";

export type Program = {
  id: string;
  name: string;
  category: "Learning" | "Community" | "Building" | "Funding";
  images: string[];
  description: string;
  whoCanApply: string[];
  applyUrl: string;
  lastEdition: { label: string; value: string }[];
};

const names: [string, Program["category"]][] = [
  ["Girls Who Yap (GWY)", "Community"],
  ["DoraDAO World Tour", "Community"],
  ["DoraBoot", "Learning"],
  ["Dora AI Academy", "Learning"],
  ["Matchmaker", "Building"],
  ["Talent Directory", "Building"],
  ["Community Starter", "Community"],
  ["NGO Grants", "Funding"],
  ["Dora Labs", "Building"],
  ["Founder Fellowship", "Funding"],
];

export const programs: Program[] = names.map(([name, category], i) => ({
  id: name.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
  name,
  category,
  images: [0, 1, 2].map((k) => img(`prog-${i}-${k}`, 900, 600)),
  description: `${name} is a placeholder description. It brings members together to learn, build and grow through workshops, mentorship and real-world projects.`,
  whoCanApply: ["Students and early-career professionals", "Members of any Dora chapter", "Builders with an idea to share", "Anyone committed to the code of conduct"],
  applyUrl: "#",
  lastEdition: [
    { label: "Edition", value: `#${(i % 4) + 2}` },
    { label: "Participants", value: `${300 + i * 85}` },
    { label: "Cities", value: `${6 + i}` },
    { label: "Duration", value: `${4 + (i % 3) * 2} weeks` },
  ],
}));

export const programCategories = ["All", "Learning", "Community", "Building", "Funding"] as const;
