import { img } from "./site";

export const resourceTypes = ["All", "Research & Studies", "Industry Resources", "Member Resources", "Guides & Toolkits", "Videos"] as const;
export type ResourceType = Exclude<(typeof resourceTypes)[number], "All">;

export type Resource = {
  id: string;
  type: ResourceType;
  title: string;
  excerpt: string;
  readMinutes: number;
  image: string;
  url: string;
};

export const featuredResource = {
  title: "I Am Dora: stories from our members",
  description: "A short film about the people who make Dora what it is.",
  youtubeId: "RuxhXE2QOIM",
};

const r = (id: string, type: ResourceType, title: string, excerpt: string, readMinutes: number): Resource => ({
  id, type, title, excerpt, readMinutes, image: img(`res-${id}`, 600, 360), url: "#",
});

export const resources: Resource[] = [
  r("community-report-2026", "Research & Studies", "Community Report 2026: What 60K members told us", "Survey insights on belonging, learning and careers across 45 countries.", 8),
  r("gwy-impact", "Research & Studies", "Girls Who Yap impact study", "How public speaking programs change confidence and career outcomes.", 6),
  r("cost-calculator", "Industry Resources", "Community partnership value calculator", "Estimate the reach and impact of partnering with Dora chapters.", 4),
  r("talent-pipeline", "Industry Resources", "How to build a sustainable talent pipeline", "Practical steps for companies working with community talent.", 7),
  r("evaluate-partnership", "Industry Resources", "How to evaluate a community partnership", "A checklist for universities, NGOs and companies.", 6),
  r("employer-brand", "Industry Resources", "Why Gen Z doesn't trust your employer brand", "And what actually fixes it, from our members' own words.", 6),
  r("meet-member", "Member Resources", "More to the story: meet our members", "An ongoing series profiling builders across the Dora community.", 12),
  r("pick-path", "Member Resources", "Dora Stories: picking a path when you have no idea", "Members share how they chose their first role or major.", 9),
  r("belong-in-tech", "Member Resources", "Dora Stories: you belong in tech", "Real stories about finding your place in the industry.", 5),
  r("chapter-kit", "Guides & Toolkits", "Start a Dora chapter toolkit", "Templates, checklists and budgets to launch in your city.", 10),
  r("event-playbook", "Guides & Toolkits", "Event host playbook", "Everything you need to run a great meetup or hackathon.", 8),
  r("grant-guide", "Guides & Toolkits", "Writing a winning NGO grant proposal", "Step-by-step guide with examples from funded projects.", 11),
  r("ai-academy-intro", "Videos", "Dora AI Academy: intro session", "Watch the opening lecture of our AI learning track.", 25),
  r("build-public", "Videos", "Build in public AMA recording", "Founders answer questions about shipping in the open.", 40),
];
